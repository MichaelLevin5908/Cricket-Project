#include "CricketTeam.h"
#include <cassert>
#include <iostream>
#include <set>

using namespace std;

set<void*> addrs;
bool recordaddrs = false;

void* operator new(size_t n)
{
    void* p = malloc(n);
    if (recordaddrs && n == sizeof(Node))
    {
        recordaddrs = false;
        addrs.insert(p);
        recordaddrs = true;
    }
    return p;
}

void operator delete(void* p) noexcept
{
    if (recordaddrs)
    {
        recordaddrs = false;
        auto it = addrs.find(p);
        if (it != addrs.end())
        {
            addrs.erase(it);
        }
        recordaddrs = true;
    }
    free(p);
}

void operator delete(void* p, std::size_t s) noexcept
{
    if (recordaddrs)
    {
        recordaddrs = false;
        auto it = addrs.find(p);
        if (it != addrs.end())
        {
            addrs.erase(it);
        }
        recordaddrs = true;
    }
    free(p);
}

void test_case_20()
{
    recordaddrs = true;
    {
        CricketTeam team;
        int oldn = addrs.size();
        team.addCricketer("Player1", "Test", "Value1");
        team.addCricketer("Player2", "Test", "Value2");
        team.addCricketer("Player3", "Test", "Value3");
        team.addCricketer("Player4", "Test", "Value4");
        assert(addrs.size() == oldn + 4);
    }
    assert(addrs.size() == 0);
    recordaddrs = false;
}

int main()
{
    test_case_20();
    cout << "Test case 20 passed" << endl;
    return 0;
}
