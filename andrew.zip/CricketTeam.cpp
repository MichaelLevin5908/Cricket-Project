#include <string>
#include <iostream>
#include <utility>
#include "CricketTeam.h"

//constructor intializes head and nullptr
CricketTeam::CricketTeam(): head(nullptr), tail(nullptr){}

bool CricketTeam::noTeam() const
{
    //check if no head or tail node
    if(head == nullptr && tail == nullptr)
    {
        return true;
    }
    return false;
}

CricketTeam::~CricketTeam()
{
    std::cerr << "Destructor called" << std::endl;
    Node *p;
	while (head != nullptr) {
		p = head;
		head = head->next;
        std::cerr << "Deleting cricketer: " << p->first << " " << p->last << " at " << p << std::endl;
		delete p;
	}
    head = nullptr;
    tail = nullptr;
}


CricketTeam::CricketTeam(const CricketTeam& rhs)
{   
    // checks if no nodes then assigns nodes
    if (rhs.head == nullptr) {
        head = nullptr;
        tail = nullptr;
    } else {
        // declares and initializes the first node
        head = new Node;
        head->value = rhs.head->value;
        head->first = rhs.head->first;
        head->last = rhs.head->last;
        head->previous = nullptr;
        head->next = nullptr; 

        // save for previous pointer
        Node *currentNew = head;
        Node *current = rhs.head->next;

        // loops and copies
        while (current != nullptr) {
            // creates new node and initializes values
            Node *newNode = new Node;
            newNode->value = current->value;
            newNode->first = current->first;
            newNode->last = current->last;
            newNode->previous = currentNew;
            
            // makes sure next value is null
            newNode->next = nullptr;

            // gives currentNew's next pointer the value of newNode
            currentNew->next = newNode;
            
            // loops one ahead
            currentNew = newNode;
            current = current->next;
        }
        // assigns the tail pointer
        tail = currentNew;
    }
}

// Swap function implementation
void CricketTeam::swap(CricketTeam& other)
{
    std::swap(head, other.head);
    std::swap(tail, other.tail);
}

const CricketTeam& CricketTeam::operator=(const CricketTeam& rhs)
{   
    // Check if it's the same object (self-assignment check)
    if (this == &rhs) {
        return *this;
    }

    // Create a temporary copy of rhs
    CricketTeam temp(rhs);

    // Swap the contents with the temporary copy
    swap(temp);

    return *this;
}

int CricketTeam::cricketerCount() const
{
    //easier vairable to see
    Node* current = head;
    int count = 0;

    //traverse through list
    while(current != nullptr)
    {
        current = current->next;
        count++;
    }
    return count;
}

// bool CricketTeam::addCricketer(const std::string& firstName, const std::string& lastName, const CricketType& value)
// {
//     // If the list is empty
//     if (head == nullptr && tail == nullptr)
//     {
//         // Initialize the new node with values
//         head = new Node;
//         std::cerr << "add cricketer "<< head; // here I am adding a new cricketer find indicator for address and note it down, cerr
//         head->value = value;
//         head->first = firstName;
//         head->last = lastName;

//         // Make sure every variable is initialized
//         head->previous = nullptr;
//         head->next = nullptr;
//         // Tail is same as head as first node
//         tail = head;
//         return true;
//     }

//     // Check for duplicates
//     Node* current = head;
//     while (current != nullptr)
//     {
//         if (current->first == firstName && current->last == lastName)
//         {
//             return false; // Duplicate found
//         }
//         current = current->next;
//     }

//     // Create a new node
//     Node* newNode = new Node;
//     newNode->value = value;
//     newNode->first = firstName;
//     newNode->last = lastName;

//     // Find the correct insertion position
//     current = head;
//     while (current != nullptr)
//     {
//         //checks if new node is in order and where it should be appended
//         if (newNode->last < current->last || (newNode->last == current->last && newNode->first < current->first))
//         {
//             // Insert newNode before current
//             newNode->next = current;
//             newNode->previous = current->previous;

//             if (current->previous != nullptr)
//             {
//                 current->previous->next = newNode;
//             }
//             else
//             {
//                 head = newNode; // Update head if newNode is inserted at the beginning
//             }

//             current->previous = newNode;
//             return true;
//         }
//         current = current->next;
//     }

//     // If we reach here, newNode should be inserted at the end
//     newNode->previous = tail;
//     tail->next = newNode;
//     newNode->next = nullptr;
//     tail = newNode; // Update the tail pointer
//     return true;
// }
bool CricketTeam::addCricketer(const std::string& firstName, const std::string& lastName, const CricketType& value) {
    // If the cricketer is already on the team, return false
    if (rosteredOnCricketTeam(firstName, lastName)) {
        return false;
    }

    // Create a new node with the cricketer's details
    Node* newNode = new Node;
    newNode->first = firstName;
    newNode->last = lastName;
    newNode->value = value;
    newNode->next = nullptr;
    newNode->previous = nullptr;

    // If the list is empty, initialize head and tail
    if (head == nullptr && tail == nullptr) {
        head = newNode;
        tail = newNode;
        std::cerr << "Inserted first cricketer: " << firstName << " " << lastName << " at " << newNode << std::endl;
        return true;
    }

    Node* temp = head;

    // Traverse the list to find the correct insertion point
    while (temp != nullptr) {
        if ((newNode->last < temp->last) || (newNode->last == temp->last && newNode->first < temp->first)) {
            // Insert newNode before temp
            newNode->next = temp;
            newNode->previous = temp->previous;

            if (temp->previous != nullptr) {
                temp->previous->next = newNode;
            } else {
                head = newNode; // Update head if newNode is inserted at the beginning
            }

            temp->previous = newNode;
            std::cerr << "Inserted cricketer: " << firstName << " " << lastName << " before " << temp << std::endl;
            return true;
        }

        if (temp->next == nullptr) {
            // If temp is the last node, insert newNode after temp
            temp->next = newNode;
            newNode->previous = temp;
            tail = newNode;
            std::cerr << "Inserted cricketer: " << firstName << " " << lastName << " at the end" << std::endl;
            return true;
        }

        temp = temp->next;
    }

    return true;
}


bool CricketTeam::substituteCricketer(const std::string& firstName, const std::string& lastName, const CricketType & value)
{
    //if no nodes
    if(head == nullptr && tail == nullptr)
    {
        return false;
    }

    //traver list

    //variable for current node
    Node* current = head;

    //traverase through list
    while(current != nullptr)
    {   
        //check if same
        if(current->first == firstName && current->last == lastName)
        {
            //change value
            current->value = value;
            return true;
        }
        current = current->next;
    }

    return false;
}

bool CricketTeam::addOrSubstitute(const std::string& firstName, const std::string& lastName, const CricketType& value)
{
    // if no nodes
    if(head == nullptr && tail == nullptr)
    {
        //intialie the new node
        head = new Node;
        head->first = firstName;
        head->last = lastName;
        head->value = value;
        //ensure previos and next are intialized
        head->previous = nullptr;
        head->next = nullptr;


        //ensure head equals tails
        tail = head;
        return true;
    }

    // traversal of list to see if nodes

    //define variable to traverse list
    Node* current = head;

    while(current != nullptr)
        {
            if(current->first == firstName && current->last == lastName)
            {
                current->value = value;
                return true;
            }
            current = current->next;
        }
    
    //go through list again to find value and insert is not there
    current = head;
    // declare new node to add
    Node* newNode = new Node;
    newNode->value = value;
    newNode->first = firstName;
    newNode->last = lastName;

    //traverses through list and appends new cricket player to the middle or the head of the linked list
    while(current != nullptr)
    {
        if(current->last > newNode->last || (current->last == newNode->last && current->first > newNode->first))
        {
            //links appended node to nodes to adjacent nodes
            newNode->next = current;
            newNode->previous = current->previous;
            if(current->previous != nullptr)
            {
                //links next node to newNode
                current->previous->next = newNode;
            }
            else
            {
                //if node is first makes it head
                head = newNode;
            }
            return true;
        }
        current = current->next;
    }
    //ensure tail is correctly defined if traverses through list and the name is last
    newNode->previous = tail;
    tail->next = newNode;
    tail = newNode;
    newNode->next = nullptr;
    return true;
}

bool CricketTeam::releaseCricketer(const std::string& firstName, const std::string& lastName)
{   
    //if no nodes
    if(head == nullptr && tail == nullptr)
    {
        return false;
    }

    //traverse through list

    //easier variable to see current node
    Node* current = head;

    while(current != nullptr)
    {

        if(current->first == firstName && current->last == lastName)
        {
            //only one node
            if(current == head && current == tail)
            {
                delete current;
                head = nullptr;
                tail = nullptr;
            }
            //if the node is in front 
            else if(head == current)
            {
                head = head->next;
                head->previous = nullptr;
                delete current;
            }
            //if node is in the back
            else if(tail == current)
            {
                tail = tail->previous;
                tail->next = nullptr;
                delete current;
            }
            //in the middle
            else
            {
                //save values
                Node* before = current->previous;
                Node* after = current->next;
                //give them values
                before->next = after;
                after->previous = before;

                delete current;
            }
            return true;
        }
        current = current->next;
    }
    return false;
}

bool CricketTeam::rosteredOnCricketTeam(const std::string& firstName, const std::string& lastName) const
{
    //if no nodes
    if(head == nullptr && tail == nullptr)
    {
        return false;
    }

    //find if in the team
    
    //vairable to traverse
    Node* current = head;

    while(current != nullptr)
    {
        if(current->first == firstName && current->last == lastName)
        {
            return true;
        }
        current = current->next;
    }
    return false;
}

bool CricketTeam::searchForCricketer(const std::string& firstName, const std::string& lastName, CricketType& value) const
{
    //if no nodes
    if(head == nullptr && tail == nullptr)
    {
        return false;
    }

    //traverse through list

    //variable to traverse
    Node* current  = head;

    while(current != nullptr)
    {
        if(current->first == firstName && current->last == lastName)
        {
            //sets value equal to the value in the list
            value = current->value;
            return true;
        }
        current = current->next;
    }
    return false;
}

//check if I can use cricketerCount function
bool CricketTeam::checkTeamForCricketer(int i, std::string& firstName, std::string& lastName, CricketType& value) const
{   
    //check if no nodes
    if(tail == nullptr && head == nullptr)
    {
        return false;
    }

    // Check if the index is within bounds
    if (i < 0 || i >= cricketerCount())
    {
        return false;
    }

    // Traverse through the list
    Node* current = head;

    for (int index = 0; index < i && current != nullptr; ++index)
    {
        current = current->next;
    }

    // If current is not nullptr, copy the data
    if (current != nullptr)
    {
        firstName = current->first;
        lastName = current->last;
        value = current->value;
        return true;
    }

    return false;
}

void CricketTeam::tradeCricketTeams(CricketTeam& other)
{
    //save both head and tail variables
    Node* temp_h = head;
    Node* temp_t = tail;
    //swap both variables
    head = other.head;
    other.head = temp_h;
    tail = other.tail;
    other.tail = temp_t;
}

bool mergeCricketers(const CricketTeam & odOne, const CricketTeam & odTwo, CricketTeam & odJoined)
{
    bool isConsistent = true;
    CricketType valueOne, valueTwo;
    std::string first, last;

    CricketTeam tempTeam;

    //add list from odOne into joined without with values same in both
    for(int i = 0; i < odOne.cricketerCount();i++)
    {
        //retrieves values
        if(odOne.checkTeamForCricketer(i, first, last, valueOne))
        //searches all of list two to see if those values are in it
            if (odTwo.searchForCricketer(first, last, valueTwo))
            //compares for concistency in value vairable of both lists
                if(valueOne == valueTwo)
                    tempTeam.addOrSubstitute(first,last,valueOne);
                else
                {
                    isConsistent = false;
                }
        else
        {
            tempTeam.addOrSubstitute(first,last,valueOne);
        }
    }

    //add values in second list
    for(int i = 0; i < odTwo.cricketerCount();i++)
    {
        //retrieves values of every cricket
        if(odTwo.checkTeamForCricketer(i, first, last, valueTwo)) 
        {
            //makes sure that is not the same as list one
            if(!odOne.searchForCricketer(first, last, valueOne)) 
                {
                    //adds cricket
                    tempTeam.addOrSubstitute(first, last, valueTwo);
                }
        }
    }
    //delete existing memory in odJoined
    for(int i = 0; i < odJoined.cricketerCount();i++)
        {
            //retrieves values
            if(odJoined.checkTeamForCricketer(i, first, last, valueOne))
            {
                //deletes node
                odJoined.releaseCricketer(first, last);
            }
        }
    // Copy cricketers from tempTeam to odJoined
    for (int i = 0; i < tempTeam.cricketerCount(); i++) 
        {
            if (tempTeam.checkTeamForCricketer(i, first, last, valueOne)) {
                odJoined.addOrSubstitute(first, last, valueOne);
            }
        }
    return isConsistent;
}

void checkCricketers (const std::string& fsearch, const std::string& lsearch, const CricketTeam& odOne, CricketTeam& odResult)
{   
    //declaration of variables to hold values
    CricketType value;
    std::string first, last;

    CricketTeam tempTeam;

     // Traverse through odOne and add matching cricketers to tempTeam
    for(int i = 0; i < odOne.cricketerCount(); i++) {
        if(odOne.checkTeamForCricketer(i, first, last, value)) {
            // Check if the value matches the search criteria
            if ((first == fsearch || fsearch == "*") && (last == lsearch || lsearch == "*")) {
                tempTeam.addOrSubstitute(first, last, value);
            }
        }
    }

    //make sure oddResult has its memory deallocated
    for(int i = 0; i < odResult.cricketerCount();i++)
    {
        if(odResult.checkTeamForCricketer(i,first, last, value))
            {
                odResult.releaseCricketer(first,last);
            }
    }

    //make sure memory is not delallocated if the same array 
    for(int i = 0; i < tempTeam.cricketerCount(); i++) {
        if(tempTeam.checkTeamForCricketer(i, first, last, value)) {
            odResult.addOrSubstitute(first, last, value);
        }
    }
}
